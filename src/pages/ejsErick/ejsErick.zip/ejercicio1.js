//Ejercicio 1
function invertirCadena(str){
  return str.split("").reverse().join("")
}
//Test Ejericio 1
console.log("Test 1:",invertirCadena("javascript")==="tpircsavaj"?"Pasó":"Falló")
