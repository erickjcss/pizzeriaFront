//Ejercicio 2 
function encontrarMaximo(arr){ 
return Math.max(...arr)}; 
//Test Ejercicio 2
console.log(encontrarMaximo([7,2,9,4,1])===9?"Pasó":"Falló")